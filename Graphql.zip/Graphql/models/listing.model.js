const mongoose = require('mongoose');

const listingShema = mongoose.Schema({
    listing_title: {
        type: String,
        required: true,
        trim: true,
    },
    description: {
        type: String,
        required: true,
        trim: true,

    },
    street: {
        type: String,
        required: true,
        trim: true,

    },
    city: {
        type: String,
        required: true,
        trim: true,

    },
    postal_code: {
        type: String,
        required: true,
        trim: true,

    },
    price: {
        type: Number,
        required: true,

    },
    email: {
        type: String,
        required: true,
    },

}, {
    timestamps: true,
});

const Message = mongoose.model('Listing', listingShema);

module.exports = Message;