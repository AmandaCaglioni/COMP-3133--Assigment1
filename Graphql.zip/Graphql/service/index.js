const User = require('../models/user.model');

const createUser = async (userBody) => {
    console.log(userBody)
    await User.create(userBody);
};

const getUser = async () => {
    await User.find();
};
module.exports = {
    createUser,
    getUser,
}