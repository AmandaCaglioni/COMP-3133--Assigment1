const express = require('express');
const app = express();
const mongoose = require('mongoose');
const cors = require('cors');
const morgan = require('morgan');
const graphql = require('graphql');
const { GraphQLObjectType, GraphQLSchema, GraphQLInt, GraphQLString, GraphQLList } = require('graphql')
const { graphqlHTTP } = require("express-graphql");
const userService = require('./service/index.js');

mongoose.connect('mongodb://localhost:27017/Airbnb').then((success) => {
    console.log('Successfully connected to database');
}).catch((error) => {
    console.log(error);
    process.exit(1);
});

const userType = new GraphQLObjectType({
    name: "User",
    fields: () => ({
        id: { type: GraphQLInt },
        firstname: { type: GraphQLString },
        lastname: { type: GraphQLString },
        email: { type: GraphQLString },
    })
})
const RootQuery = new GraphQLObjectType({
    name: "RootQueryType",
    fields: {
        getAllUsers: {
            type: new GraphQLList(userType),
            args: { id: { type: GraphQLInt } },
            resolve(parent, args) {
                return userService.getUser();
            }
        }
    }
});
const Mutation = new GraphQLObjectType({
    name: "Mutation",
    fields: {
        createUser: {
            type: userType,
            args: {
                firstname: { type: GraphQLString },
                lastname: { type: GraphQLString },
                password: { type: GraphQLString },
                email: { type: GraphQLString },
            },
            resolve(parent, args) {
                return userService.createUser({ firstname: firstname, lastname: lastname, password: password, email: email, type: type });

            }
        }
    }
})

const schema = new GraphQLSchema({ query: RootQuery, mutation: Mutation });













app.use('/graphql', graphqlHTTP({
    schema,
    graphiql: true,
}))
app.listen(3000, () => console.log("Server is listening on PORT 3000"))