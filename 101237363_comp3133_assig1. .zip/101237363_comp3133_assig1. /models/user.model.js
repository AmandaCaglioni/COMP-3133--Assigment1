const mongoose = require('mongoose');
const validator = require('validator');
const { isValidPassword } = require('mongoose-custom-validators')

const userSchema = mongoose.Schema({
    username: {
        type: String,
        required: false,
        trim: true,
    },
    firstname: {
        type: String,
        required: true,
        trim: true,
    },
    lastname: {
        type: String,
        required: true,
        trim: true,
    },
    password: {
        type: String,
        required: true,
        validate: {
            validator: (str) => isValidPassword(str, { uppercase: true, lowercase: true, minlength: 6 }),
            message: 'Password must have at least: 1 lowercase letter, 1 number, and 1 special character.'
        }
    },
    email: {
        type: String,
        required: true,
        validate(value) {
            if (!validator.isEmail(value)) {
                throw new Error('Invalid email');
            }
        },
    },
    type: {
        type: String,
        enum: ['admin', 'customer'],
        default: 'customer',
    },
    token: {
        type: String,
    },
}, {
    timestamps: true
},
);

const User = mongoose.model('User', userSchema);

module.exports = User;